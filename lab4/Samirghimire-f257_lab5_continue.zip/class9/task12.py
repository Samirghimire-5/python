num = int(input("Enter a number: "))
if (num > 0 and num % 2 == 0 and num % 5 == 0):
  print("This Number is positive, even and divisible by 5")
else: 
  print("The three number doesnt match all criteria")