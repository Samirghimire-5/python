password = input("enter a password: ")
if (password == "admin123"):
  print("login Successful")
else: 
  print("incorrect password")
