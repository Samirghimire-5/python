number = int(input("Enter a Number: "))
if (number%2 == 0 and number%3 == 0):
  print("Valid Number")
else:
  print("invalid Number")